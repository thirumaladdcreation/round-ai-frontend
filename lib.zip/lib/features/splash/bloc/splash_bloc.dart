import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:round_ai/features/splash/bloc/splash_event.dart';
import 'package:round_ai/features/splash/bloc/splash_state.dart';
import 'package:round_ai/features/splash/repository/splash_repository.dart';

class SplashBloc extends Bloc<SplashEvent, SplashState> {
  SplashBloc(this._repository) : super(const SplashWaiting()) {
    on<SplashStarted>(_onStarted);
  }

  final SplashRepository _repository;

  /// The splash artwork already shows the loading line.
  /// The pause only keeps the brand readable before routing.
  static const Duration hold = Duration(milliseconds: 1600);

  Future<void> _onStarted(
    SplashStarted event,
    Emitter<SplashState> emit,
  ) async {
    await Future<void>.delayed(hold);
    if (isClosed) return;
    emit(SplashReady(_repository.destination()));
  }
}
