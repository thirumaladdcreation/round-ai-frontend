import 'package:equatable/equatable.dart';

sealed class SplashState extends Equatable {
  const SplashState();
}

class SplashWaiting extends SplashState {
  const SplashWaiting();

  @override
  List<Object?> get props => <Object?>[];
}

class SplashReady extends SplashState {
  const SplashReady(this.route);

  final String route;

  @override
  List<Object?> get props => <Object?>[route];
}
