import 'package:round_ai/core/router/app_routes.dart';
import 'package:round_ai/core/storage/app_storage.dart';
import 'package:round_ai/features/splash/repository/splash_repository.dart';

class SplashRepositoryImpl implements SplashRepository {
  const SplashRepositoryImpl(this._storage);

  final AppStorage _storage;

  @override
  String destination() {
    if (!_storage.hasAuthToken) return AppRoutes.signIn;
    if (!_storage.hasSelectedTeam) return AppRoutes.selectTeam;
    return AppRoutes.today;
  }
}
