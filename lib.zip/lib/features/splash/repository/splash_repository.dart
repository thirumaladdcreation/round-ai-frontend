abstract class SplashRepository {
  /// Next route from the saved session. Does not choose a team.
  String destination();
}
