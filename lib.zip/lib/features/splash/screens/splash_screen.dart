import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:round_ai/core/di/injection_container.dart';
import 'package:round_ai/features/splash/widgets/splash_backdrop.dart';
import 'package:round_ai/features/splash/bloc/splash_bloc.dart';
import 'package:round_ai/features/splash/bloc/splash_event.dart';
import 'package:round_ai/features/splash/bloc/splash_state.dart';
import 'package:round_ai/features/splash/repository/splash_repository.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({this.repository, super.key});

  final SplashRepository? repository;

  @override
  Widget build(BuildContext context) {
    final SplashRepository source =
        repository ?? InjectionContainer.instance.splashRepository;
    return BlocProvider<SplashBloc>(
      create: (_) => SplashBloc(source)..add(const SplashStarted()),
      child: const SplashArtwork(),
    );
  }
}

class SplashArtwork extends StatelessWidget {
  const SplashArtwork({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocListener<SplashBloc, SplashState>(
      listenWhen: (_, SplashState next) => next is SplashReady,
      listener: (BuildContext context, SplashState state) {
        if (state is SplashReady) context.go(state.route);
      },
      child: const SplashBackdrop(),
    );
  }
}
