import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

/// A team the signed-in clinician is allowed to open.
class ClinicalTeam extends Equatable {
  const ClinicalTeam({
    required this.id,
    required this.name,
    required this.unit,
    required this.patientCount,
    required this.icon,
    required this.tint,
  });

  final String id;
  final String name;

  /// Service label shown on the card, such as Team A.
  final String unit;
  final int patientCount;
  final IconData icon;
  final Color tint;

  @override
  List<Object> get props => <Object>[id, name, unit, patientCount];
}

/// Demo assignment for Dr. Rivera. Teams outside this list are not shown.
const List<ClinicalTeam> demoTeams = <ClinicalTeam>[
  ClinicalTeam(
    id: 'internal-medicine',
    name: 'Internal Medicine',
    unit: 'Team A',
    patientCount: 12,
    icon: Icons.medical_services_outlined,
    tint: Color(0xFF4A9EFF),
  ),
  ClinicalTeam(
    id: 'icu',
    name: 'ICU Team',
    unit: 'Team B',
    patientCount: 8,
    icon: Icons.monitor_heart_outlined,
    tint: Color(0xFF39B8AD),
  ),
  ClinicalTeam(
    id: 'cardiology',
    name: 'Cardiology Team',
    unit: 'Team C',
    patientCount: 10,
    icon: Icons.favorite_border_rounded,
    tint: Color(0xFFE11D48),
  ),
  ClinicalTeam(
    id: 'surgery',
    name: 'Surgery Team',
    unit: 'Team D',
    patientCount: 10,
    icon: Icons.content_cut_rounded,
    tint: Color(0xFF6D28D9),
  ),
];

ClinicalTeam? teamById(String? id) {
  for (final ClinicalTeam team in demoTeams) {
    if (team.id == id) return team;
  }
  return null;
}
