import 'package:flutter/material.dart';
import 'package:round_ai/core/theme/app_colors.dart';
import 'package:round_ai/core/theme/app_typography.dart';
import 'package:round_ai/features/census/data/demo_patients.dart';
import 'package:round_ai/features/patient/data/patient_workspace.dart';
import 'package:round_ai/shared/widgets/workflow_page.dart';

class PresentationScreen extends StatelessWidget {
  const PresentationScreen({required this.patientId, super.key});

  final String patientId;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    final CensusPatient? patient = patientById(patientId);
    final PatientWorkspace? workspace = workspaceFor(patientId);
    if (patient == null || workspace == null) {
      return const WorkflowPage(
        title: 'Presentation',
        children: <Widget>[Text('This patient is not on your team.')],
      );
    }

    return WorkflowPage(
      title: 'Presentation',
      status: 'Draft ready · requires review',
      children: <Widget>[
        Text(
          '${patient.name} · Room ${patient.room}',
          style: AppTypography.bold(fontSize: 22, color: colors.navy),
        ),
        const SizedBox(height: 6),
        Text(
          'About 60–90 seconds. Old findings stay dated.',
          style: AppTypography.regular(color: colors.textSecondary),
        ),
        const SizedBox(height: 16),
        InfoCard(
          title: 'Oral draft',
          label: 'AI interpretation',
          body: workspace.oralDraft,
          tint: colors.aiCard,
          border: colors.aiBorder,
        ),
        const SizedBox(height: 12),
        InfoCard(
          title: 'Expanded review',
          label: 'From chart',
          body: workspace.expandedReview
              .map((String line) => '• $line')
              .join('\n'),
        ),
        const SizedBox(height: 12),
        InfoCard(
          title: 'What changed',
          label: 'From chart',
          body: workspace.changes.map((String line) => '• $line').join('\n'),
        ),
        const SizedBox(height: 12),
        InfoCard(
          title: 'Missing',
          body: workspace.missing.map((String line) => '• $line').join('\n'),
        ),
      ],
    );
  }
}
