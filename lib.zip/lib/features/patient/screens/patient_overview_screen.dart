import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:round_ai/core/router/app_routes.dart';
import 'package:round_ai/core/theme/app_colors.dart';
import 'package:round_ai/core/theme/app_typography.dart';
import 'package:round_ai/features/census/data/demo_patients.dart';
import 'package:round_ai/features/patient/data/patient_workspace.dart';

class PatientOverviewScreen extends StatefulWidget {
  const PatientOverviewScreen({required this.patientId, super.key});

  final String patientId;

  @override
  State<PatientOverviewScreen> createState() => _PatientOverviewScreenState();
}

class _PatientOverviewScreenState extends State<PatientOverviewScreen> {
  int _tab = 0;
  bool _refreshing = false;
  String _generatedLabel = 'Not generated';

  Future<void> _refresh() async {
    setState(() => _refreshing = true);
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;
    setState(() {
      _refreshing = false;
      _generatedLabel = 'Draft ready · just now';
    });
  }

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    final CensusPatient? patient = patientById(widget.patientId);
    if (patient == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Patient')),
        body: const Center(child: Text('This patient is not on your team.')),
      );
    }

    return Scaffold(
      backgroundColor: colors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: <Widget>[
            Row(
              children: <Widget>[
                IconButton(
                  onPressed: () => context.pop(),
                  icon: const Icon(Icons.arrow_back_rounded),
                ),
                Text(
                  'Patient Overview',
                  style: AppTypography.semiBold(
                    fontSize: 18,
                    color: colors.textPrimary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _Header(patient: patient),
            const SizedBox(height: 16),
            _Tabs(
              index: _tab,
              onChanged: (int index) => _openSection(index, patient.id),
            ),
            const SizedBox(height: 16),
            _OverviewBody(
              patient: patient,
              workspace: workspaceFor(patient.id),
              refreshing: _refreshing,
              generatedLabel: _generatedLabel,
              onRefresh: _refresh,
              onDraftNote: () => context.push(AppRoutes.notePath(patient.id)),
              onEvidence: () =>
                  context.push(AppRoutes.evidencePath(patient.id)),
              onPresentation: () =>
                  context.push(AppRoutes.presentationPath(patient.id)),
              onTeach: () => context.push(AppRoutes.teachPath(patient.id)),
            ),
          ],
        ),
      ),
    );
  }

  void _openSection(int index, String patientId) {
    switch (index) {
      case 1:
        context.push(AppRoutes.notePath(patientId));
      case 2:
        context.push(AppRoutes.evidencePath(patientId));
      case 3:
        context.push(AppRoutes.patientTasksPath(patientId));
      case 4:
        context.push(AppRoutes.signOutPath(patientId));
      default:
        setState(() => _tab = 0);
    }
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.patient});

  final CensusPatient patient;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    final String initials = patient.name
        .split(' ')
        .where((String part) => part.isNotEmpty)
        .map((String part) => part[0])
        .take(2)
        .join();
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        CircleAvatar(
          radius: 28,
          backgroundColor: colors.primary.withValues(alpha: 0.12),
          child: Text(
            initials,
            style: AppTypography.bold(fontSize: 16, color: colors.primary),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                patient.name,
                style: AppTypography.bold(
                  fontSize: 22,
                  color: colors.textPrimary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'MRN: #${patient.mrn}  ·  ${patient.detail}',
                style: AppTypography.regular(
                  color: colors.textSecondary,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: <Widget>[
                  _MetaChip(
                    icon: Icons.meeting_room_outlined,
                    label: 'Room ${patient.room}',
                  ),
                  _MetaChip(
                    icon: Icons.favorite_border,
                    label: patient.codeStatus,
                  ),
                  _MetaChip(icon: Icons.schedule, label: patient.updatedLabel),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MetaChip extends StatelessWidget {
  const _MetaChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 14, color: colors.textSecondary),
          const SizedBox(width: 4),
          Text(
            label,
            style: AppTypography.medium(
              fontSize: 12,
              color: colors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _Tabs extends StatelessWidget {
  const _Tabs({required this.index, required this.onChanged});

  final int index;
  final ValueChanged<int> onChanged;

  static const List<String> labels = <String>[
    'Overview',
    'Notes',
    'Evidence',
    'Tasks',
    'Sign-out',
  ];

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: List<Widget>.generate(labels.length, (int i) {
          final bool selected = i == index;
          return Padding(
            padding: const EdgeInsets.only(right: 16),
            child: InkWell(
              onTap: () => onChanged(i),
              child: Column(
                children: <Widget>[
                  Text(
                    labels[i],
                    style: AppTypography.semiBold(
                      color: selected ? colors.navy : colors.textMuted,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    height: 3,
                    width: 28,
                    decoration: BoxDecoration(
                      color: selected ? colors.primary : Colors.transparent,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _OverviewBody extends StatelessWidget {
  const _OverviewBody({
    required this.patient,
    required this.workspace,
    required this.refreshing,
    required this.generatedLabel,
    required this.onRefresh,
    required this.onDraftNote,
    required this.onEvidence,
    required this.onPresentation,
    required this.onTeach,
  });

  final CensusPatient patient;
  final PatientWorkspace? workspace;
  final bool refreshing;
  final String generatedLabel;
  final VoidCallback onRefresh;
  final VoidCallback onDraftNote;
  final VoidCallback onEvidence;
  final VoidCallback onPresentation;
  final VoidCallback onTeach;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: colors.aiCard,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: colors.aiBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Icon(Icons.auto_awesome, size: 16, color: colors.aiAccent),
                  const SizedBox(width: 6),
                  Text(
                    'AI Patient Summary',
                    style: AppTypography.semiBold(
                      color: colors.aiAccent,
                      fontSize: 14,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    'View Details',
                    style: AppTypography.semiBold(
                      color: colors.primary,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'AI interpretation',
                style: AppTypography.medium(
                  color: colors.aiAccent,
                  fontSize: 11,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                patient.summary,
                style: AppTypography.regular(
                  height: 1.45,
                  color: colors.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                generatedLabel,
                style: AppTypography.regular(
                  color: colors.textMuted,
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: refreshing ? null : onRefresh,
                icon: refreshing
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.refresh_rounded, size: 18),
                label: Text(
                  refreshing ? 'Refreshing summary' : 'Refresh Summary',
                ),
              ),
            ],
          ),
        ),
        if (workspace != null) ...<Widget>[
          const SizedBox(height: 16),
          _BulletCard(title: 'What changed', lines: workspace!.changes),
          const SizedBox(height: 12),
          _BulletCard(title: 'Missing', lines: workspace!.missing),
        ],
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.7,
          children: <Widget>[
            _ActionTile(
              icon: Icons.campaign_outlined,
              label: 'Prepare\nPresentation',
              onTap: onPresentation,
            ),
            _ActionTile(
              icon: Icons.description_outlined,
              label: 'Draft\nNote',
              onTap: onDraftNote,
            ),
            _ActionTile(
              icon: Icons.menu_book_outlined,
              label: 'Explore\nEvidence',
              onTap: onEvidence,
            ),
            _ActionTile(
              icon: Icons.school_outlined,
              label: 'Teach Me',
              onTap: onTeach,
            ),
          ],
        ),
      ],
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    return Material(
      color: colors.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: colors.primary),
              const SizedBox(height: 8),
              Text(
                label,
                style: AppTypography.semiBold(fontSize: 13, height: 1.2),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BulletCard extends StatelessWidget {
  const _BulletCard({required this.title, required this.lines});

  final String title;
  final List<String> lines;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title, style: AppTypography.semiBold(fontSize: 15)),
          const SizedBox(height: 8),
          ...lines.map(
            (String line) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(
                '• $line',
                style: AppTypography.regular(height: 1.35),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
