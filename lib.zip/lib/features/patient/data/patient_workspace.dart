class ChartTask {
  const ChartTask({
    required this.id,
    required this.patientId,
    required this.patientName,
    required this.title,
  });

  final String id;
  final String patientId;
  final String patientName;
  final String title;
}

class TeachItem {
  const TeachItem({
    required this.topic,
    required this.vignette,
    required this.leadIn,
    required this.options,
    required this.correctIndex,
    required this.correctExplanation,
    required this.distractorExplanations,
    required this.objective,
    required this.takeaway,
  });

  final String topic;
  final String vignette;
  final String leadIn;
  final List<String> options;
  final int correctIndex;
  final String correctExplanation;
  final List<String> distractorExplanations;
  final String objective;
  final String takeaway;
}

class PatientWorkspace {
  const PatientWorkspace({
    required this.patientId,
    required this.changes,
    required this.missing,
    required this.oralDraft,
    required this.expandedReview,
    required this.evidenceTopic,
    required this.tasks,
    required this.signOut,
    required this.question,
  });

  final String patientId;
  final List<String> changes;
  final List<String> missing;
  final String oralDraft;
  final List<String> expandedReview;
  final String evidenceTopic;
  final List<ChartTask> tasks;
  final String signOut;
  final TeachItem question;
}

const List<PatientWorkspace> demoWorkspaces = <PatientWorkspace>[
  PatientWorkspace(
    patientId: 'p-509a',
    changes: <String>[
      'The morning brief notes increasing oxygen need overnight.',
      'The morning brief also notes worsening renal function with low documented urine output.',
    ],
    missing: <String>[
      'A measured oxygen amount is not stored.',
      'A urine output number is not stored.',
      'Today’s examination and plan have not been entered.',
    ],
    oralDraft:
        'Rosa Martinez is the next patient on this demo list, room 509A. The brief describes increasing oxygen need and worsening renal function with low documented urine output. Amounts are not in the chart, and today’s plan has not been entered.',
    expandedReview: <String>[
      'From the demo brief: increasing oxygen need overnight.',
      'From the demo brief: worsening renal function with low documented urine output.',
      'Not entered: today’s examination and clinician plan.',
    ],
    evidenceTopic: 'oxygen need and acute kidney injury',
    tasks: <ChartTask>[],
    signOut:
        'Demo patient in room 509A. The brief describes increasing oxygen need and low documented urine output. No contingency instruction is included until a clinician writes one.',
    question: TeachItem(
      topic: 'Morning brief — what was not measured',
      vignette:
          'A fictional morning brief says a patient has increasing oxygen need and low documented urine output. No oxygen flow and no urine volume are written as numbers.',
      leadIn: 'What can be said from that brief alone?',
      options: <String>[
        'State a specific oxygen flow and a specific urine volume.',
        'The brief describes both problems, and the amounts are not documented.',
        'Treat the brief as a signed order to change treatment.',
        'Mark the patient stable because a number is missing.',
        'Copy another patient’s oxygen setting into this chart.',
      ],
      correctIndex: 1,
      correctExplanation:
          'The brief can be repeated as a description. Missing measurements stay missing.',
      distractorExplanations: <String>[
        'A number that was never written should not be stated.',
        'A brief is not an order and does not sign a treatment change.',
        'Missing a number does not make the issue stable.',
        'Another patient’s data never moves into this chart.',
      ],
      objective:
          'Repeat a brief without inventing the measurements it left out.',
      takeaway: 'Describe the problem, and do not invent the missing amount.',
    ),
  ),
  PatientWorkspace(
    patientId: 'p-102',
    changes: <String>[
      'A newer chart entry still documents fever and breathing difficulty.',
      'The latest lab entry documents an elevated white-cell count. No earlier value is stored here, so a numeric trend is not calculated.',
    ],
    missing: <String>[
      'Oxygen support is not documented.',
      'Today’s examination has not been entered.',
      'Today’s clinician plan has not been entered.',
    ],
    oralDraft:
        'This is a fictional 68-year-old man admitted with pneumonia. Fever and breathing difficulty are documented. The latest labs document an elevated white-cell count. Oxygen support, today’s examination, and today’s plan are missing, so those items should not be stated as known.',
    expandedReview: <String>[
      'Documented problem: pneumonia.',
      'Documented findings: fever, breathing difficulty, elevated white-cell count.',
      'Unknown: oxygen support, today’s examination, and the clinician’s plan.',
    ],
    evidenceTopic: 'community-acquired pneumonia in older adults',
    tasks: <ChartTask>[
      ChartTask(
        id: 't-102-oxygen',
        patientId: 'p-102',
        patientName: 'John Smith',
        title: 'Document oxygen support',
      ),
      ChartTask(
        id: 't-102-exam',
        patientId: 'p-102',
        patientName: 'John Smith',
        title: 'Enter today’s examination',
      ),
    ],
    signOut:
        'Fictional patient in room 102, admitted with pneumonia. Fever, breathing difficulty, and an elevated white-cell count are documented. Oxygen support and today’s plan are still open. No contingency threshold is included until a clinician writes one.',
    question: TeachItem(
      topic: 'Pneumonia — documented versus missing',
      vignette:
          'A fictional older adult is admitted with cough. The chart says fever was documented. The amount of oxygen, if any, is not written anywhere in the chart.',
      leadIn: 'Which statement is the most accurate reading of this chart?',
      options: <String>[
        'The patient should be described as afebrile.',
        'Fever is documented, and oxygen support is unknown.',
        'Yesterday’s examination can be copied forward as today’s examination.',
        'The most recently uploaded file replaces every earlier fact.',
        'A missing plan can be filled with a suggested treatment and then signed.',
      ],
      correctIndex: 1,
      correctExplanation:
          'The chart documents fever. It does not document oxygen, so oxygen stays unknown rather than being guessed.',
      distractorExplanations: <String>[
        'Afebrile would mean fever is documented as absent. This chart documents fever.',
        'An old examination keeps its original date and is not today’s examination unless the clinician confirms the carry-forward.',
        'Upload time is not the same as the clinical event time, and a new file does not erase conflicting facts.',
        'A suggested plan is not a signed plan. The clinician has to enter and adopt it.',
      ],
      objective:
          'Separate a documented finding from information the chart does not contain.',
      takeaway: 'Say what the chart documents, and name what is still missing.',
    ),
  ),
  PatientWorkspace(
    patientId: 'p-105',
    changes: <String>[
      'Weight and yesterday’s oxygen requirement are on the chart.',
      'Today’s examination is still absent, so yesterday’s finding is not presented as today’s examination.',
    ],
    missing: <String>[
      'Today’s examination has not been entered.',
      'Today’s clinician plan has not been entered.',
    ],
    oralDraft:
        'This is a fictional 72-year-old woman admitted with congestive heart failure. Weight and yesterday’s oxygen requirement are documented. Today’s examination and today’s plan have not been entered.',
    expandedReview: <String>[
      'Documented problem: congestive heart failure.',
      'Documented: weight and yesterday’s oxygen requirement.',
      'Unknown today: examination and clinician plan.',
    ],
    evidenceTopic: 'congestive heart failure',
    tasks: <ChartTask>[
      ChartTask(
        id: 't-105-exam',
        patientId: 'p-105',
        patientName: 'Mary Johnson',
        title: 'Enter today’s examination',
      ),
    ],
    signOut:
        'Fictional patient in room 105 with congestive heart failure. Yesterday’s oxygen requirement is documented. Today’s examination and plan are open. Contingency instructions are blank until the clinician adds them.',
    question: TeachItem(
      topic: 'Heart failure — time of a finding',
      vignette:
          'A fictional patient was admitted with heart failure. Yesterday’s note records an oxygen requirement. No examination is filed for today.',
      leadIn:
          'How should yesterday’s oxygen requirement be used on rounds today?',
      options: <String>[
        'State it as today’s examination.',
        'State it as yesterday’s documented finding, not as today’s examination.',
        'Drop it because only today’s file matters.',
        'Treat the upload time of yesterday’s note as the clinical event time.',
        'Invent today’s oxygen flow because yesterday had a value.',
      ],
      correctIndex: 1,
      correctExplanation:
          'The finding stays attached to yesterday. It can be mentioned with that date. It is not today’s examination.',
      distractorExplanations: <String>[
        'Calling it today’s examination changes the time of the observation.',
        'An older documented finding can still matter. It is not deleted because a newer file is missing.',
        'Upload time and the clinical event time are different.',
        'A missing value stays missing. The draft does not invent a number.',
      ],
      objective:
          'Keep the clinical time of a finding when presenting an update.',
      takeaway:
          'An older finding stays dated. It does not become today’s examination.',
    ),
  ),
  PatientWorkspace(
    patientId: 'p-107',
    changes: <String>[
      'Pain and diet are documented on postoperative day 1.',
      'Drain output is not in the chart, and neither is the surgeon’s latest recommendation.',
    ],
    missing: <String>[
      'Drain output is not documented.',
      'The surgeon’s latest recommendation is not documented.',
      'Today’s clinician plan has not been entered.',
    ],
    oralDraft:
        'This is a fictional 59-year-old man on postoperative day 1. Pain and diet are documented. Drain output and the surgeon’s latest recommendation are missing. Code status is documented as DNR. No contingency instruction has been written by the clinician.',
    expandedReview: <String>[
      'Documented: postoperative day 1, pain, diet, DNR.',
      'Missing: drain output, surgeon recommendation, and today’s plan.',
    ],
    evidenceTopic: 'routine postoperative day 1 assessment',
    tasks: <ChartTask>[
      ChartTask(
        id: 't-107-drain',
        patientId: 'p-107',
        patientName: 'Robert Davis',
        title: 'Record drain output if measured',
      ),
    ],
    signOut:
        'Fictional patient in room 107, postoperative day 1, DNR. Pain and diet are documented. Drain output and the surgeon’s recommendation are open. Do not add a rescue treatment unless the clinician writes it.',
    question: TeachItem(
      topic: 'Postoperative chart — what was not written',
      vignette:
          'A fictional patient is on the first day after surgery. Pain and diet are written down. Drain output and the surgeon’s latest recommendation are not in the chart.',
      leadIn: 'What should the draft say about the drain and the surgeon?',
      options: <String>[
        'Report a normal drain output and a routine surgeon recommendation.',
        'Say that pain and diet are documented, and that drain output and the surgeon’s recommendation are missing.',
        'Omit the surgery because the surgeon’s note is missing.',
        'Copy another patient’s postoperative plan into this chart.',
        'Mark the problem resolved because the newest file does not repeat it.',
      ],
      correctIndex: 1,
      correctExplanation:
          'Documented items can be stated. Missing drain output and a missing recommendation stay missing.',
      distractorExplanations: <String>[
        'A normal output or a recommendation that was never written would be invented.',
        'The postoperative day is documented. A missing recommendation does not erase that.',
        'Facts from another patient never move into this chart.',
        'Silence in a new file does not prove an issue resolved when the chart has not said so.',
      ],
      objective:
          'Keep documented postoperative facts and explicitly list what was not written.',
      takeaway:
          'Do not fill a missing surgeon recommendation or a missing measurement.',
    ),
  ),
];

PatientWorkspace? workspaceFor(String patientId) {
  for (final PatientWorkspace workspace in demoWorkspaces) {
    if (workspace.patientId == patientId) return workspace;
  }
  return null;
}

List<ChartTask> get allDemoTasks {
  return demoWorkspaces.expand((PatientWorkspace item) => item.tasks).toList();
}

/// Accepted proposals for this demo session. Accepting does not write an order.
class DemoTaskBoard {
  DemoTaskBoard._();

  static final Map<String, bool> accepted = <String, bool>{};

  static bool isAccepted(String taskId) => accepted[taskId] ?? false;

  static void accept(String taskId) {
    accepted[taskId] = true;
  }
}
