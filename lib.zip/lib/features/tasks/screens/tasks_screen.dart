import 'package:flutter/material.dart';
import 'package:round_ai/core/theme/app_colors.dart';
import 'package:round_ai/core/theme/app_typography.dart';
import 'package:round_ai/features/patient/data/patient_workspace.dart';
import 'package:round_ai/shared/widgets/app_button.dart';
import 'package:round_ai/shared/widgets/workflow_page.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({this.patientId, super.key});

  final String? patientId;

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    final List<ChartTask> tasks = widget.patientId == null
        ? allDemoTasks
        : allDemoTasks
              .where((ChartTask task) => task.patientId == widget.patientId)
              .toList();

    final Widget body = ListView(
      padding: EdgeInsets.fromLTRB(
        20,
        widget.patientId == null ? 24 : 8,
        20,
        24,
      ),
      children: <Widget>[
        if (widget.patientId == null)
          Text(
            'Tasks',
            style: AppTypography.bold(fontSize: 28, color: colors.textPrimary),
          )
        else
          const SizedBox.shrink(),
        if (widget.patientId == null) const SizedBox(height: 6),
        Text(
          'Proposals stay unassigned until you accept them. Accepting does not create an order.',
          style: AppTypography.regular(
            color: colors.textSecondary,
            height: 1.4,
          ),
        ),
        const SizedBox(height: 16),
        ...tasks.map((ChartTask task) {
          final bool accepted = DemoTaskBoard.isAccepted(task.id);
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: colors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: colors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    task.title,
                    style: AppTypography.semiBold(
                      fontSize: 16,
                      color: colors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${task.patientName} · Owner Unassigned · Deadline Not entered',
                    style: AppTypography.regular(
                      color: colors.textSecondary,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 10),
                  if (accepted)
                    Text(
                      'Accepted',
                      style: AppTypography.semiBold(
                        color: colors.accent,
                        fontSize: 13,
                      ),
                    )
                  else
                    AppButton(
                      label: 'Accept',
                      variant: AppButtonVariant.outline,
                      expand: false,
                      onPressed: () =>
                          setState(() => DemoTaskBoard.accept(task.id)),
                    ),
                ],
              ),
            ),
          );
        }),
      ],
    );

    if (widget.patientId != null) {
      return WorkflowPage(
        title: 'Tasks',
        status: 'Proposed',
        children: <Widget>[
          Text(
            'Proposals stay unassigned until you accept them.',
            style: AppTypography.regular(color: colors.textSecondary),
          ),
          const SizedBox(height: 12),
          ...tasks.map((ChartTask task) {
            final bool accepted = DemoTaskBoard.isAccepted(task.id);
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: colors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: colors.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      task.title,
                      style: AppTypography.semiBold(
                        fontSize: 16,
                        color: colors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Owner Unassigned · Deadline Not entered',
                      style: AppTypography.regular(
                        color: colors.textSecondary,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 10),
                    if (accepted)
                      Text(
                        'Accepted',
                        style: AppTypography.semiBold(
                          color: colors.accent,
                          fontSize: 13,
                        ),
                      )
                    else
                      AppButton(
                        label: 'Accept',
                        variant: AppButtonVariant.outline,
                        expand: false,
                        onPressed: () =>
                            setState(() => DemoTaskBoard.accept(task.id)),
                      ),
                  ],
                ),
              ),
            );
          }),
        ],
      );
    }

    return Scaffold(
      backgroundColor: colors.background,
      body: SafeArea(child: body),
    );
  }
}
