import 'package:equatable/equatable.dart';

class ForgotPasswordState extends Equatable {
  const ForgotPasswordState({
    this.submitting = false,
    this.accepted = false,
    this.error,
  });

  final bool submitting;
  final bool accepted;
  final String? error;

  ForgotPasswordState copyWith({
    bool? submitting,
    bool? accepted,
    String? error,
    bool clearError = false,
  }) {
    return ForgotPasswordState(
      submitting: submitting ?? this.submitting,
      accepted: accepted ?? this.accepted,
      error: clearError ? null : error ?? this.error,
    );
  }

  @override
  List<Object?> get props => <Object?>[submitting, accepted, error];
}
