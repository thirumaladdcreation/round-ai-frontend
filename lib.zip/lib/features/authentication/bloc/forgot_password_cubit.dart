import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:round_ai/core/errors/result.dart';
import 'package:round_ai/features/authentication/bloc/forgot_password_state.dart';
import 'package:round_ai/features/authentication/repository/auth_repository.dart';

/// Accepts a hospital email. It does not send a reset message.
class ForgotPasswordCubit extends Cubit<ForgotPasswordState> {
  ForgotPasswordCubit(this._repository) : super(const ForgotPasswordState());

  final AuthRepository _repository;

  Future<void> submit(String email) async {
    emit(state.copyWith(submitting: true, clearError: true));
    final Result<void> result = await _repository.requestPasswordReset(
      email: email,
    );
    result.when(
      ok: (_) => emit(
        state.copyWith(submitting: false, accepted: true, clearError: true),
      ),
      err: (failure) =>
          emit(state.copyWith(submitting: false, error: failure.message)),
    );
  }
}
