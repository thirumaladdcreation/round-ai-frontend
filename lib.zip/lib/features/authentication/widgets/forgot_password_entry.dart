import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:round_ai/app/app_colors.dart';
import 'package:round_ai/app/app_typography.dart';
import 'package:round_ai/core/router/app_routes.dart';
import 'package:round_ai/features/authentication/bloc/forgot_password_cubit.dart';
import 'package:round_ai/features/authentication/bloc/forgot_password_state.dart';
import 'package:round_ai/shared/widgets/app_text_field.dart';
import 'package:round_ai/shared/widgets/app_button.dart';

class ForgotPasswordEntry extends StatelessWidget {
  const ForgotPasswordEntry({
    required this.controller,
    required this.state,
    super.key,
  });

  final TextEditingController controller;
  final ForgotPasswordState state;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        AppTextField(
          controller: controller,
          label: 'Email Address',
          hint: 'doctor@hospital.com',
          icon: Icons.mail_outline_rounded,
          keyboardType: TextInputType.emailAddress,
        ),
        if (state.error != null) ...<Widget>[
          const SizedBox(height: 12),
          Text(
            state.error!,
            style: AppTypography.regular(color: palette.error, fontSize: 13),
          ),
        ],
        const SizedBox(height: 20),
        AppButton(
          label: 'Request reset',
          loading: state.submitting,
          onPressed: state.submitting
              ? null
              : () =>
                    context.read<ForgotPasswordCubit>().submit(controller.text),
        ),
      ],
    );
  }
}

class ForgotPasswordResult extends StatelessWidget {
  const ForgotPasswordResult({super.key});

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          'No email was sent.',
          style: AppTypography.headingSemiBold(color: palette.textPrimary),
        ),
        const SizedBox(height: 8),
        Text(
          'Hospital password reset is not connected. '
          'Return to sign in and use your demo password.',
          style: AppTypography.bodyMedium(color: palette.textSecondary),
        ),
        const SizedBox(height: 20),
        AppButton(
          label: 'Back to sign in',
          onPressed: () => context.go(AppRoutes.signIn),
        ),
      ],
    );
  }
}
