import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:round_ai/app/app_colors.dart';
import 'package:round_ai/app/app_typography.dart';
import 'package:round_ai/core/di/injection_container.dart';
import 'package:round_ai/core/router/app_routes.dart';
import 'package:round_ai/features/authentication/bloc/forgot_password_cubit.dart';
import 'package:round_ai/features/authentication/bloc/forgot_password_state.dart';
import 'package:round_ai/features/authentication/repository/auth_repository.dart';
import 'package:round_ai/features/authentication/widgets/forgot_password_entry.dart';

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({this.repository, super.key});

  final AuthRepository? repository;

  @override
  Widget build(BuildContext context) {
    final AuthRepository source =
        repository ?? InjectionContainer.instance.authRepository;
    return BlocProvider<ForgotPasswordCubit>(
      create: (_) => ForgotPasswordCubit(source),
      child: const ForgotPasswordForm(),
    );
  }
}

class ForgotPasswordForm extends StatefulWidget {
  const ForgotPasswordForm({super.key});

  @override
  State<ForgotPasswordForm> createState() => ForgotPasswordFormState();
}

class ForgotPasswordFormState extends State<ForgotPasswordForm> {
  final TextEditingController _emailController = TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = AppPalette.of(context);
    return Scaffold(
      backgroundColor: palette.background,
      body: SafeArea(
        child: BlocBuilder<ForgotPasswordCubit, ForgotPasswordState>(
          builder: (BuildContext context, ForgotPasswordState state) {
            return ListView(
              padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
              children: <Widget>[
                Align(
                  alignment: Alignment.centerLeft,
                  child: IconButton(
                    tooltip: 'Back',
                    onPressed: () => context.go(AppRoutes.signIn),
                    icon: Icon(
                      Icons.arrow_back_rounded,
                      color: palette.textPrimary,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Reset password',
                  style: AppTypography.screenHeading(color: palette.navy),
                ),
                const SizedBox(height: 8),
                Text(
                  'Enter the email on your hospital account. '
                  'No reset email is sent in this demo.',
                  style: AppTypography.bodyMedium(color: palette.textSecondary),
                ),
                const SizedBox(height: 24),
                if (state.accepted)
                  const ForgotPasswordResult()
                else
                  ForgotPasswordEntry(
                    controller: _emailController,
                    state: state,
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
