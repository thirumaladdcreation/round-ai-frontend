import 'package:flutter/material.dart';

enum PatientStatus { critical, stable, reviewPending }

class CensusPatient {
  const CensusPatient({
    required this.id,
    required this.room,
    required this.name,
    required this.detail,
    required this.status,
    required this.updatedLabel,
    required this.mrn,
    required this.codeStatus,
    required this.summary,
    required this.accent,
    required this.icon,
  });

  final String id;
  final String room;
  final String name;
  final String detail;
  final PatientStatus status;
  final String updatedLabel;
  final String mrn;
  final String codeStatus;
  final String summary;
  final Color accent;
  final IconData icon;

  String get statusLabel {
    return switch (status) {
      PatientStatus.critical => 'Critical',
      PatientStatus.stable => 'Stable',
      PatientStatus.reviewPending => 'Review Pending',
    };
  }
}

const List<CensusPatient> demoPatients = <CensusPatient>[
  CensusPatient(
    id: 'p-509a',
    room: '509A',
    name: 'Rosa Martinez',
    detail: 'Worsening oxygen need + AKI',
    status: PatientStatus.critical,
    updatedLabel: 'Updated 9:36',
    mrn: '50901',
    codeStatus: 'Full Code',
    summary:
        'Demo brief: increasing oxygen need overnight, and worsening renal function with low documented urine output. Today’s examination and plan are not entered.',
    accent: Color(0xFFE11D48),
    icon: Icons.favorite_rounded,
  ),
  CensusPatient(
    id: 'p-102',
    room: '102',
    name: 'John Smith',
    detail: '68 yrs · Pneumonia',
    status: PatientStatus.critical,
    updatedLabel: 'Updated 10m ago',
    mrn: '12345',
    codeStatus: 'Full Code',
    summary:
        '68-year-old male admitted with pneumonia. Fever and breathing difficulty documented. Latest labs show elevated WBC. Oxygen support details are missing.',
    accent: Color(0xFFE11D48),
    icon: Icons.air_rounded,
  ),
  CensusPatient(
    id: 'p-105',
    room: '105',
    name: 'Mary Johnson',
    detail: '72 yrs · CHF',
    status: PatientStatus.stable,
    updatedLabel: 'Updated 20m ago',
    mrn: '12388',
    codeStatus: 'Full Code',
    summary:
        '72-year-old woman admitted with congestive heart failure. Weight and oxygen requirement from yesterday are on the chart. Today’s exam has not been entered.',
    accent: Color(0xFF2563EB),
    icon: Icons.favorite_border_rounded,
  ),
  CensusPatient(
    id: 'p-107',
    room: '107',
    name: 'Robert Davis',
    detail: '59 yrs · Post Surgery',
    status: PatientStatus.reviewPending,
    updatedLabel: 'Updated 1h ago',
    mrn: '12402',
    codeStatus: 'DNR',
    summary:
        '59-year-old man, post-operative day 1. Pain and diet are documented. Drain output and the surgeon’s latest recommendation are missing.',
    accent: Color(0xFFD97706),
    icon: Icons.medical_services_outlined,
  ),
];

CensusPatient? patientById(String id) {
  for (final CensusPatient patient in demoPatients) {
    if (patient.id == id) return patient;
  }
  return null;
}
