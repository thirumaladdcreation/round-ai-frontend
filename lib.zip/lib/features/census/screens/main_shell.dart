import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:round_ai/features/patient/data/patient_workspace.dart';
import 'package:round_ai/shared/widgets/app_bottom_nav_bar.dart';
import 'package:round_ai/shared/widgets/app_menu_drawer.dart';

class MainShell extends StatelessWidget {
  const MainShell({required this.navigationShell, super.key});

  final StatefulNavigationShell navigationShell;

  String? _openTaskBadge() {
    final int pending = allDemoTasks
        .where((ChartTask task) => !DemoTaskBoard.isAccepted(task.id))
        .length;
    if (pending == 0) return null;
    return '$pending';
  }

  void _onItemSelected(int index) {
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    final MediaQueryData media = MediaQuery.of(context);
    final double keyboard = media.viewInsets.bottom;
    final double navHeight = 64 + media.padding.bottom;
    final double insetAboveNav = keyboard > navHeight
        ? keyboard - navHeight
        : 0;

    final bool dark = Theme.of(context).brightness == Brightness.dark;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
        statusBarBrightness: dark ? Brightness.dark : Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        resizeToAvoidBottomInset: false,
        drawer: const AppMenuDrawer(),
        drawerEnableOpenDragGesture: true,
        body: Column(
          children: <Widget>[
            Expanded(
              child: MediaQuery(
                data: media.copyWith(
                  viewInsets: media.viewInsets.copyWith(bottom: insetAboveNav),
                ),
                child: navigationShell,
              ),
            ),
            AppBottomNavBar(
              currentIndex: navigationShell.currentIndex,
              onItemSelected: _onItemSelected,
              tasksBadge: _openTaskBadge(),
            ),
          ],
        ),
      ),
    );
  }
}
