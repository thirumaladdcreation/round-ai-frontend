import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:round_ai/core/di/injection_container.dart';
import 'package:round_ai/core/router/app_routes.dart';
import 'package:round_ai/core/theme/app_colors.dart';
import 'package:round_ai/core/theme/app_typography.dart';
import 'package:round_ai/features/census/data/demo_patients.dart';
import 'package:round_ai/features/team/data/demo_teams.dart';
import 'package:round_ai/shared/widgets/rounds_logo.dart';

enum _CensusFilter { all, critical, reviewPending }

class CensusScreen extends StatefulWidget {
  const CensusScreen({super.key});

  @override
  State<CensusScreen> createState() => _CensusScreenState();
}

class _CensusScreenState extends State<CensusScreen> {
  _CensusFilter _filter = _CensusFilter.all;
  String _query = '';

  List<CensusPatient> get _visible {
    return demoPatients.where((CensusPatient patient) {
      final bool matchesFilter = switch (_filter) {
        _CensusFilter.all => true,
        _CensusFilter.critical => patient.status == PatientStatus.critical,
        _CensusFilter.reviewPending =>
          patient.status == PatientStatus.reviewPending,
      };
      final String haystack =
          '${patient.name} ${patient.room} ${patient.detail}'.toLowerCase();
      final bool matchesQuery =
          _query.isEmpty || haystack.contains(_query.toLowerCase());
      return matchesFilter && matchesQuery;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    final String name = InjectionContainer.instance.appStorage.clinicianName;
    final team = teamById(
      InjectionContainer.instance.appStorage.selectedTeamId,
    );
    final int critical = demoPatients
        .where((CensusPatient p) => p.status == PatientStatus.critical)
        .length;
    final int pending = demoPatients
        .where((CensusPatient p) => p.status == PatientStatus.reviewPending)
        .length;

    return Scaffold(
      backgroundColor: colors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          children: <Widget>[
            Row(
              children: <Widget>[
                const RoundsWordmark(compact: true),
                const Spacer(),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.notifications_none_rounded),
                ),
                CircleAvatar(
                  radius: 16,
                  backgroundColor: colors.primary,
                  child: Text(
                    'TG',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Good Morning, $name',
              style: AppTypography.bold(
                fontSize: 22,
                color: colors.textPrimary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              team == null
                  ? 'Here is your patient census for today'
                  : '${team.name} · fictional demo census',
              style: AppTypography.regular(color: colors.textSecondary),
            ),
            const SizedBox(height: 16),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: <Widget>[
                  _FilterChip(
                    label: 'All Patients  ${demoPatients.length}',
                    selected: _filter == _CensusFilter.all,
                    onTap: () => setState(() => _filter = _CensusFilter.all),
                  ),
                  const SizedBox(width: 8),
                  _FilterChip(
                    label: 'Critical  $critical',
                    selected: _filter == _CensusFilter.critical,
                    onTap: () =>
                        setState(() => _filter = _CensusFilter.critical),
                  ),
                  const SizedBox(width: 8),
                  _FilterChip(
                    label: 'Pending Review  $pending',
                    selected: _filter == _CensusFilter.reviewPending,
                    onTap: () =>
                        setState(() => _filter = _CensusFilter.reviewPending),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              onChanged: (String value) => setState(() => _query = value),
              decoration: InputDecoration(
                hintText: 'Search patients...',
                hintStyle: AppTypography.regular(color: colors.textMuted),
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: colors.inputFill,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide(color: colors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide(color: colors.border),
                ),
              ),
            ),
            const SizedBox(height: 14),
            if (_visible.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 32),
                child: Text(
                  'No patients match this view.',
                  textAlign: TextAlign.center,
                  style: AppTypography.regular(color: colors.textSecondary),
                ),
              )
            else
              ..._visible.map(
                (CensusPatient patient) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _PatientRow(
                    patient: patient,
                    onTap: () =>
                        context.push(AppRoutes.patientPath(patient.id)),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    return Material(
      color: selected ? colors.primary : colors.surface,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: selected ? colors.primary : colors.border,
            ),
          ),
          child: Text(
            label,
            style: AppTypography.semiBold(
              color: selected ? colors.white : colors.textSecondary,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}

class _PatientRow extends StatelessWidget {
  const _PatientRow({required this.patient, required this.onTap});

  final CensusPatient patient;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    final Color badgeBg = switch (patient.status) {
      PatientStatus.critical => colors.criticalBg,
      PatientStatus.stable => colors.stableBg,
      PatientStatus.reviewPending => colors.pendingBg,
    };
    final Color badgeFg = switch (patient.status) {
      PatientStatus.critical => colors.critical,
      PatientStatus.stable => colors.stable,
      PatientStatus.reviewPending => colors.pending,
    };

    return Material(
      color: colors.surface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: colors.border),
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 5,
                height: 78,
                decoration: BoxDecoration(
                  color: patient.accent,
                  borderRadius: const BorderRadius.horizontal(
                    left: Radius.circular(18),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Icon(patient.icon, color: patient.accent, size: 20),
              const SizedBox(width: 8),
              Text(
                patient.room,
                style: AppTypography.bold(
                  fontSize: 16,
                  color: colors.textPrimary,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const SizedBox(height: 12),
                    Text(
                      patient.name,
                      style: AppTypography.semiBold(
                        fontSize: 15,
                        color: colors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      patient.detail,
                      style: AppTypography.regular(
                        color: colors.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: badgeBg,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      patient.statusLabel,
                      style: AppTypography.semiBold(
                        color: badgeFg,
                        fontSize: 11,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    patient.updatedLabel,
                    style: AppTypography.regular(
                      color: colors.textMuted,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
              Icon(Icons.chevron_right_rounded, color: colors.textMuted),
              const SizedBox(width: 6),
            ],
          ),
        ),
      ),
    );
  }
}
