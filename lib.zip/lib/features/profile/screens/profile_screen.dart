import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:round_ai/app/app_colors.dart';
import 'package:round_ai/app/theme_mode_picker.dart';
import 'package:round_ai/core/di/injection_container.dart';
import 'package:round_ai/core/router/app_routes.dart';
import 'package:round_ai/core/theme/app_typography.dart';
import 'package:round_ai/features/team/data/demo_teams.dart';
import 'package:round_ai/shared/widgets/app_button.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final storage = InjectionContainer.instance.appStorage;
    final team = teamById(storage.selectedTeamId);
    final AppPalette palette = AppPalette.of(context);
    return Scaffold(
      backgroundColor: palette.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  if (context.canPop())
                    IconButton(
                      onPressed: () => context.pop(),
                      icon: Icon(
                        Icons.arrow_back_rounded,
                        color: palette.textPrimary,
                      ),
                    ),
                  Text(
                    'Profile',
                    style: AppTypography.bold(
                      fontSize: 28,
                      color: palette.navy,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                storage.clinicianName,
                style: AppTypography.semiBold(
                  fontSize: 18,
                  color: palette.textPrimary,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                team?.name ?? 'No team selected',
                style: AppTypography.regular(color: palette.textSecondary),
              ),
              const SizedBox(height: 8),
              Text(
                storage.rememberedEmail ?? 'Email not remembered',
                style: AppTypography.regular(color: palette.textSecondary),
              ),
              const SizedBox(height: 24),
              const ThemeModePicker(),
              const Spacer(),
              AppButton(
                label: 'Sign out',
                variant: AppButtonVariant.outline,
                onPressed: () async {
                  await InjectionContainer.instance.logout();
                  if (context.mounted) context.go(AppRoutes.signIn);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
