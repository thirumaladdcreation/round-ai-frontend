import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:round_ai/core/router/app_routes.dart';
import 'package:round_ai/features/authentication/screens/forgot_password_screen.dart';
import 'package:round_ai/features/authentication/screens/sign_in_screen.dart';
import 'package:round_ai/features/census/screens/census_screen.dart';
import 'package:round_ai/features/census/screens/main_shell.dart';
import 'package:round_ai/features/learning/screens/learning_screen.dart';
import 'package:round_ai/features/learning/screens/teach_screen.dart';
import 'package:round_ai/features/patient/screens/evidence_screen.dart';
import 'package:round_ai/features/patient/screens/note_screen.dart';
import 'package:round_ai/features/patient/screens/patient_overview_screen.dart';
import 'package:round_ai/features/patient/screens/presentation_screen.dart';
import 'package:round_ai/features/patient/screens/sign_out_screen.dart';
import 'package:round_ai/features/profile/screens/profile_screen.dart';
import 'package:round_ai/features/rounds/screens/rounds_screen.dart';
import 'package:round_ai/features/tasks/screens/tasks_screen.dart';
import 'package:round_ai/features/splash/screens/splash_screen.dart'; 
import 'package:round_ai/features/team_selection/screens/select_team_screen.dart';
import 'package:round_ai/features/today/screens/today_screen.dart';

class AppRouter {
  const AppRouter._();

  static final GlobalKey<NavigatorState> rootNavigatorKey =
      GlobalKey<NavigatorState>(debugLabel: 'root');

  static final GlobalKey<NavigatorState> _todayNavigatorKey =
      GlobalKey<NavigatorState>(debugLabel: 'today');
  static final GlobalKey<NavigatorState> _censusNavigatorKey =
      GlobalKey<NavigatorState>(debugLabel: 'census');
  static final GlobalKey<NavigatorState> _roundsNavigatorKey =
      GlobalKey<NavigatorState>(debugLabel: 'rounds');
  static final GlobalKey<NavigatorState> _profileNavigatorKey =
      GlobalKey<NavigatorState>(debugLabel: 'profile');
  static final GlobalKey<NavigatorState> _tasksNavigatorKey =
      GlobalKey<NavigatorState>(debugLabel: 'tasks');

  static final GoRouter router = GoRouter(
    navigatorKey: rootNavigatorKey,
    initialLocation: AppRoutes.splash,
    routes: <RouteBase>[
      GoRoute(path: AppRoutes.splash, builder: (_, _) => const SplashScreen()),
      GoRoute(path: AppRoutes.signIn, builder: (_, _) => const SignInScreen()),
      GoRoute(
        path: AppRoutes.forgotPassword,
        builder: (_, _) => const ForgotPasswordScreen(),
      ),
      GoRoute(
        path: AppRoutes.selectTeam,
        builder: (_, _) => const SelectTeamScreen(),
      ),
      GoRoute(
        path: AppRoutes.patientNote,
        parentNavigatorKey: rootNavigatorKey,
        builder: (BuildContext context, GoRouterState state) {
          return NoteScreen(patientId: state.pathParameters['patientId'] ?? '');
        },
      ),
      GoRoute(
        path: AppRoutes.patientEvidence,
        parentNavigatorKey: rootNavigatorKey,
        builder: (BuildContext context, GoRouterState state) {
          return EvidenceScreen(
            patientId: state.pathParameters['patientId'] ?? '',
          );
        },
      ),
      GoRoute(
        path: AppRoutes.patientPresentation,
        parentNavigatorKey: rootNavigatorKey,
        builder: (BuildContext context, GoRouterState state) {
          return PresentationScreen(
            patientId: state.pathParameters['patientId'] ?? '',
          );
        },
      ),
      GoRoute(
        path: AppRoutes.patientSignOut,
        parentNavigatorKey: rootNavigatorKey,
        builder: (BuildContext context, GoRouterState state) {
          return SignOutScreen(
            patientId: state.pathParameters['patientId'] ?? '',
          );
        },
      ),
      GoRoute(
        path: AppRoutes.patientTeach,
        parentNavigatorKey: rootNavigatorKey,
        builder: (BuildContext context, GoRouterState state) {
          return TeachScreen(
            patientId: state.pathParameters['patientId'] ?? '',
          );
        },
      ),
      GoRoute(
        path: AppRoutes.patientTasks,
        parentNavigatorKey: rootNavigatorKey,
        builder: (BuildContext context, GoRouterState state) {
          return TasksScreen(
            patientId: state.pathParameters['patientId'] ?? '',
          );
        },
      ),
      GoRoute(
        path: AppRoutes.patient,
        parentNavigatorKey: rootNavigatorKey,
        builder: (BuildContext context, GoRouterState state) {
          final String patientId = state.pathParameters['patientId'] ?? '';
          return PatientOverviewScreen(patientId: patientId);
        },
      ),
      GoRoute(
        path: AppRoutes.learning,
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, _) => const LearningScreen(),
      ),
      StatefulShellRoute.indexedStack(
        builder:
            (
              BuildContext context,
              GoRouterState state,
              StatefulNavigationShell navigationShell,
            ) {
              return MainShell(navigationShell: navigationShell);
            },
        branches: <StatefulShellBranch>[
          StatefulShellBranch(
            navigatorKey: _todayNavigatorKey,
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.today,
                pageBuilder: (BuildContext context, GoRouterState state) {
                  return const NoTransitionPage<void>(child: TodayScreen());
                },
              ),
            ],
          ),
          StatefulShellBranch(
            navigatorKey: _censusNavigatorKey,
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.census,
                pageBuilder: (BuildContext context, GoRouterState state) {
                  return const NoTransitionPage<void>(child: CensusScreen());
                },
              ),
            ],
          ),
          StatefulShellBranch(
            navigatorKey: _roundsNavigatorKey,
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.rounds,
                pageBuilder: (BuildContext context, GoRouterState state) {
                  return const NoTransitionPage<void>(child: RoundsScreen());
                },
              ),
            ],
          ),
          StatefulShellBranch(
            navigatorKey: _tasksNavigatorKey,
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.tasks,
                pageBuilder: (BuildContext context, GoRouterState state) {
                  return const NoTransitionPage<void>(child: TasksScreen());
                },
              ),
            ],
          ),
          StatefulShellBranch(
            navigatorKey: _profileNavigatorKey,
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.profile,
                pageBuilder: (BuildContext context, GoRouterState state) {
                  return const NoTransitionPage<void>(child: ProfileScreen());
                },
              ),
            ],
          ),
        ],
      ),
    ],
  );
}
