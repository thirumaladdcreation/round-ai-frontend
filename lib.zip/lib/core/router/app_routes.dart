class AppRoutes {
  const AppRoutes._();

  static const String splash = '/';
  static const String signIn = '/sign-in';
  static const String forgotPassword = '/forgot-password';
  static const String selectTeam = '/select-team';

  static const String census = '/census';
  static const String today = '/today';
  static const String rounds = '/rounds';
  static const String learning = '/learning';
  static const String tasks = '/tasks';
  static const String profile = '/profile';

  static const String patient = '/patient/:patientId';
  static const String patientNote = '/patient/:patientId/note';
  static const String patientEvidence = '/patient/:patientId/evidence';
  static const String patientPresentation = '/patient/:patientId/presentation';
  static const String patientSignOut = '/patient/:patientId/sign-out';
  static const String patientTeach = '/patient/:patientId/teach';
  static const String patientTasks = '/patient/:patientId/tasks';

  static String patientPath(String patientId) => '/patient/$patientId';
  static String notePath(String patientId) => '/patient/$patientId/note';
  static String evidencePath(String patientId) =>
      '/patient/$patientId/evidence';
  static String presentationPath(String patientId) =>
      '/patient/$patientId/presentation';
  static String signOutPath(String patientId) => '/patient/$patientId/sign-out';
  static String teachPath(String patientId) => '/patient/$patientId/teach';
  static String patientTasksPath(String patientId) =>
      '/patient/$patientId/tasks';
}
