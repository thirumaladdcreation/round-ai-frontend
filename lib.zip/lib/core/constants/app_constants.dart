class AppConstants {
  const AppConstants._();

  static const String appName = 'RoundsAI';
  static const Duration connectTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);

  static const String authTokenKey = 'auth_token';
  static const String rememberMeKey = 'remember_me';
  static const String rememberedEmailKey = 'remembered_email';
  static const String clinicianNameKey = 'clinician_name';
  static const String selectedTeamIdKey = 'selected_team_id';
  static const String themeModeKey = 'theme_mode';
}
