/// All REST paths. Keep base URL in env; keep paths here.
class ApiEndpoints {
  const ApiEndpoints._();

  static const String login = '/api/auth/login';
  static const String me = '/api/users/me';
  static const String teams = '/api/teams';
  static const String patients = '/api/patients';
}
