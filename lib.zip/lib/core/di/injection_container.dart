import 'package:round_ai/core/network/api_client.dart';
import 'package:round_ai/core/storage/app_storage.dart';
import 'package:round_ai/core/utils/app_log.dart';
import 'package:round_ai/features/authentication/repository/auth_repository.dart';
import 'package:round_ai/features/authentication/repository/auth_repository_impl.dart';
import 'package:round_ai/features/splash/repository/splash_repository.dart';
import 'package:round_ai/features/splash/repository/splash_repository_impl.dart';
import 'package:round_ai/features/team_selection/repository/team_repository.dart';
import 'package:round_ai/features/team_selection/repository/team_repository_impl.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Manual DI — one place to build data / domain / presentation.
class InjectionContainer {
  InjectionContainer._();

  static final InjectionContainer instance = InjectionContainer._();

  late final SharedPreferences _sharedPreferences;
  late final AppStorage appStorage;
  late final ApiClient apiClient;
  late final AuthRepository authRepository;
  late final SplashRepository splashRepository;
  late final TeamRepository teamRepository;

  Future<void> init() async {
    _sharedPreferences = await SharedPreferences.getInstance();
    appStorage = AppStorage(_sharedPreferences);
    apiClient = ApiClient(storage: appStorage);
    authRepository = AuthRepositoryImpl(appStorage);
    splashRepository = SplashRepositoryImpl(appStorage);
    teamRepository = TeamRepositoryImpl(appStorage);
    AppLog.line('[DI] ready');
  }

  bool get isLoggedIn => appStorage.hasAuthToken;

  Future<void> logout() async {
    await appStorage.clearAuthSession();
  }
}
