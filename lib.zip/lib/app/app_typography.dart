import 'package:flutter/material.dart';
import 'package:round_ai/app/app_colors.dart';
import 'package:round_ai/core/utils/screen_utils.dart';

/// Poppins styles for the whole app. Weights are the bundled font files.
class AppTypography {
  const AppTypography._();

  static const String fontFamily = 'Poppins';
  static const String interFamily = 'Inter';

  static TextStyle inter(TextStyle style) {
    return style.copyWith(fontFamily: interFamily);
  }

  static double _scaled(double size) {
    return ScreenUtils.isInitialized ? ScreenUtils.sp(size) : size;
  }

  static TextStyle _style({
    required FontWeight weight,
    required double fontSize,
    required double height,
    required Color color,
    double letterSpacing = 0,
  }) {
    return TextStyle(
      fontFamily: fontFamily,
      fontWeight: weight,
      fontSize: _scaled(fontSize),
      height: height,
      letterSpacing: letterSpacing,
      color: color,
    );
  }

  static TextStyle display({Color color = AppColors.lightNavy}) {
    return _style(
      weight: FontWeight.w700,
      fontSize: 32,
      height: 1.15,
      color: color,
      letterSpacing: -0.4,
    );
  }

  static TextStyle screenHeading({Color color = AppColors.lightNavy}) {
    return _style(
      weight: FontWeight.w700,
      fontSize: 28,
      height: 1.15,
      color: color,
      letterSpacing: -0.3,
    );
  }

  static TextStyle sectionHeading({Color color = AppColors.lightText}) {
    return _style(
      weight: FontWeight.w600,
      fontSize: 18,
      height: 1.25,
      color: color,
    );
  }

  static TextStyle headingSemiBold({Color color = AppColors.lightText}) {
    return _style(
      weight: FontWeight.w600,
      fontSize: 16,
      height: 1.25,
      color: color,
    );
  }

  static TextStyle headingMedium({Color color = AppColors.lightText}) {
    return _style(
      weight: FontWeight.w500,
      fontSize: 16,
      height: 1.25,
      color: color,
    );
  }

  static TextStyle bodyLarge({Color color = AppColors.lightText}) {
    return _style(
      weight: FontWeight.w400,
      fontSize: 16,
      height: 1.4,
      color: color,
    );
  }

  static TextStyle bodyMedium({Color color = AppColors.lightText}) {
    return _style(
      weight: FontWeight.w400,
      fontSize: 14,
      height: 1.4,
      color: color,
    );
  }

  static TextStyle bodySmall({Color color = AppColors.lightMuted}) {
    return _style(
      weight: FontWeight.w400,
      fontSize: 13,
      height: 1.35,
      color: color,
    );
  }

  static TextStyle caption({Color color = AppColors.lightMuted}) {
    return _style(
      weight: FontWeight.w400,
      fontSize: 12,
      height: 1.3,
      color: color,
    );
  }

  static TextStyle label({Color color = AppColors.lightText}) {
    return _style(
      weight: FontWeight.w500,
      fontSize: 14,
      height: 1.25,
      color: color,
    );
  }

  static TextStyle button({Color color = AppColors.lightWhite}) {
    return _style(
      weight: FontWeight.w600,
      fontSize: 16,
      height: 1.2,
      color: color,
    );
  }

  /// Existing screens call these four helpers. They now resolve to Poppins.
  static TextStyle regular({
    Color color = AppColors.lightText,
    double fontSize = 14,
    double height = 1.35,
  }) {
    return _style(
      weight: FontWeight.w400,
      fontSize: fontSize,
      height: height,
      color: color,
    );
  }

  static TextStyle medium({
    Color color = AppColors.lightText,
    double fontSize = 16,
    double height = 1.25,
  }) {
    return _style(
      weight: FontWeight.w500,
      fontSize: fontSize,
      height: height,
      color: color,
    );
  }

  static TextStyle semiBold({
    Color color = AppColors.lightText,
    double fontSize = 16,
    double height = 1.2,
  }) {
    return _style(
      weight: FontWeight.w600,
      fontSize: fontSize,
      height: height,
      color: color,
    );
  }

  static TextStyle bold({
    Color color = AppColors.lightNavy,
    double fontSize = 28,
    double height = 1.1,
  }) {
    return _style(
      weight: FontWeight.w700,
      fontSize: fontSize,
      height: height,
      color: color,
      letterSpacing: -0.3,
    );
  }
}
