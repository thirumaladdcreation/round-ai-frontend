import 'package:flutter/material.dart';
import 'package:round_ai/core/theme/app_colors.dart';
import 'package:round_ai/core/theme/app_typography.dart';

class AppBottomNavBar extends StatelessWidget {
  const AppBottomNavBar({
    required this.currentIndex,
    required this.onItemSelected,
    this.tasksBadge,
    super.key,
  });

  final int currentIndex;
  final ValueChanged<int> onItemSelected;
  final String? tasksBadge;

  List<_NavSpec> get _items => <_NavSpec>[
    _NavSpec(Icons.home_rounded, Icons.home_outlined, 'Home'),
    _NavSpec(Icons.people_alt_rounded, Icons.people_alt_outlined, 'Census'),
    _NavSpec(Icons.monitor_heart, Icons.monitor_heart_outlined, 'Rounds'),
    _NavSpec(
      Icons.fact_check_rounded,
      Icons.fact_check_outlined,
      'Tasks',
      badge: tasksBadge,
    ),
    _NavSpec(Icons.person_rounded, Icons.person_outline_rounded, 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    final double bottom = MediaQuery.paddingOf(context).bottom;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: colors.surface,
        border: Border(top: BorderSide(color: colors.border)),
      ),
      child: Padding(
        padding: EdgeInsets.only(top: 8, bottom: bottom > 0 ? bottom : 10),
        child: Row(
          children: List<Widget>.generate(_items.length, (int index) {
            final _NavSpec item = _items[index];
            final bool selected = index == currentIndex;
            final Color color = selected ? colors.primary : colors.textMuted;
            return Expanded(
              child: InkWell(
                onTap: () => onItemSelected(index),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    _BadgedIcon(
                      icon: selected ? item.selectedIcon : item.icon,
                      color: color,
                      badge: item.badge,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item.label,
                      style: AppTypography.medium(
                        color: color,
                        fontSize: 11,
                        height: 1.1,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

class _BadgedIcon extends StatelessWidget {
  const _BadgedIcon({required this.icon, required this.color, this.badge});

  final IconData icon;
  final Color color;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = AppColors.of(context);
    return SizedBox(
      width: 32,
      height: 26,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.center,
        children: <Widget>[
          Icon(icon, color: color, size: 24),
          if (badge != null)
            Positioned(
              right: -6,
              top: -4,
              child: Container(
                width: 16,
                height: 16,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: colors.error,
                  shape: BoxShape.circle,
                ),
                child: Text(
                  badge!,
                  style: TextStyle(
                    color: colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    height: 1,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _NavSpec {
  const _NavSpec(this.selectedIcon, this.icon, this.label, {this.badge});

  final IconData selectedIcon;
  final IconData icon;
  final String label;
  final String? badge;
}
